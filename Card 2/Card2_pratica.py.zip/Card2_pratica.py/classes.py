#codigos usando tudo que aprendi no card 2
class Conta:
    def __init__(self, saldo_inicial, tipo):
        self.saldo = saldo_inicial
        self.tipo = tipo

    def depositar(self, valor):
        if valor <= 0:
            return f"Impossível depositar valores menores ou iguais a 0. Saldo atual: {self.saldo:.2f}."
        self.saldo += valor
        return f"Depósito de {valor:.2f} realizado com sucesso. Saldo atualizado para {self.saldo:.2f}."

    def sacar(self, valor):
        taxa_saque = 15  # taxa de saque
        if valor <= 0:  # verificação de valor menor ou igual a 0
            return f"Impossível sacar valores menores ou iguais a 0. Saldo atual: {self.saldo:.2f}."

        if self.saldo - (valor + taxa_saque) < 0:  # verificação de saldo insuficiente
            return f"Saldo insuficiente para realizar o saque de {valor:.2f} com a taxa de {taxa_saque:.2f}. Saldo atual: {self.saldo:.2f}."

        self.saldo -= (valor + taxa_saque)
        return f"Saque de {valor:.2f} realizado com sucesso. Taxa de {taxa_saque:.2f} aplicada. Saldo atualizado para {self.saldo:.2f}."

    def exibir_tipo(self):  # método para exibir o tipo de conta
        return f"O tipo da conta é: {self.tipo.capitalize()}."

    def verificar_saldo(self):  # método para verificar o saldo
        return f"Saldo atual: {self.saldo:.2f}."

    def alterar_tipo(self, novo_tipo):  # método para alterar o tipo de conta
        self.tipo = novo_tipo
        return f"Tipo de conta alterado para: {self.tipo.capitalize()}."

    def transferir(self, valor, conta_destino):  # método para transferir dinheiro entre contas
        if valor <= 0:
            return f"Impossível transferir valores menores ou iguais a 0. Saldo atual: {self.saldo:.2f}."
        if self.saldo < valor:
            return f"Saldo insuficiente para realizar a transferência de {valor:.2f}. Saldo atual: {self.saldo:.2f}."
        self.saldo -= valor
        conta_destino.saldo += valor
        return f"Transferência de {valor:.2f} realizada com sucesso. Saldo atualizado para {self.saldo:.2f}."

# teste de classe
banco1 = Conta(500, 'corrente')
banco2 = Conta(1000, 'poupanca')

print(banco1.depositar(500))
print(banco1.depositar(-100))

print("")

print(banco1.sacar(1000))
print(banco1.sacar(300))

print("")

print(banco1.exibir_tipo())
print(banco1.verificar_saldo())
print(banco1.alterar_tipo('poupanca'))
print(banco1.exibir_tipo())

print("")

print(banco1.transferir(200, banco2))
print(banco1.verificar_saldo())
print(banco2.verificar_saldo())