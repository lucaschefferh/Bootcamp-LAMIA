from functools import reduce

#lista de livros
livros = [
    {"titulo": "Livro A", "autor": "Autor A", "ano": 2001, "paginas": 150},
    {"titulo": "Livro B", "autor": "Autor B", "ano": 1999, "paginas": 200},
    {"titulo": "Livro C", "autor": "Autor C", "ano": 1994, "paginas": 300},
    {"titulo": "Livro D", "autor": "Autor D", "ano": 2005, "paginas": 250},
]

#funcao para receber o titulo dos livros
extrair_titulos = lambda livros: list(map(lambda livro: livro["titulo"], livros))

#funcao para calcular o numero medio de paginas
calcular_media_paginas = lambda livros: reduce(lambda acc, livro: acc + livro["paginas"], livros, 0) / len(livros)

#funcao para filtrar os livros por ano de publicacao 
filtrar_por_ano = lambda livros, ano: list(filter(lambda livro: livro["ano"] >= ano, livros))

#funcao principal
def main():
    titulos = extrair_titulos(livros)
    media_paginas = calcular_media_paginas(livros)
    livros_apos_2000 = filtrar_por_ano(livros, 2002)

    print("Títulos dos livros:", titulos)
    print("")
    print("Média de páginas dos livros:", media_paginas)
    print("")
    print("Livros publicados após o ano 2000:", livros_apos_2000)

if __name__ == "__main__":
    main()