#print("Ola Mundo")
#import pacotes.sub.arquivo

#from tipos import variaveis
#from tipos import basicos
#import tipos.lista
#import tipos.tuplas
#import tipos.dicionarios

#import operadores.unarios
#import operadores.aritmeticos
#import operadores.relacionais
#import operadores.atribuicao
#import operadores.logicos
#import operadores.ternario

#import controle.if_1
#import controle.if_2
#import controle.for_1
#import controle.While
#import controle.outros_exemplos

#from funcoes import basico
#basico.saudacao()
#basico.saudacao('Lucas')
#basico.saudacao(idade=23) 
#basico.saudacao('Lucas', 23)
#a = basico.soma_e_multi(x=12,a=5,b=6)
#print(a)
#b = basico.soma_e_multi(x=15,a=2,b=8)
#resultado = a + b
#print(resultado)

#from funcoes import args
#resultado = args.soma(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
#print(resultado)
#r = args.resultado_final(nome ="Lucas", nota=7)
#print(r)
#r = args.resultado_final(nome ="Lucas", nota=9, comportado = False)
#print(r)

#import funcoes.funcionais
#import funcoes.map_reduce
#import funcoes.lambda.py
#import funcoes.comprehesion

#import OO.produto
#import OO.herança
#import OO.membros
