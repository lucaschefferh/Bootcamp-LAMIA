from functools import reduce

alunos = [
    {"nome":"Pedro", "nota": 7.0},
    {"nome":"Francisco", "nota": 4.0},
    {"nome":"João", "nota": 3.0},
    {"nome":"Lucas", "nota": 9.0},
    {"nome":"Caio", "nota": 6.0},
]

alunos_aprovado = lambda aluno: aluno["nota"] >=7 #funcao lambda para verificar se aluno foi aprovado
alunos_honra = lambda aluno: aluno["nota"] >=9 #funcao lambda para verificar se o aluno foi quadro de honra
obter_nota = lambda aluno: aluno["nota"] #funcao lambda para obter a nota de um aluno
somar = lambda a, b: a + b #funcao lambda para somar elementos 

alunos_aprovados = filter(alunos_aprovado, alunos)  #filtra os alunos aprovados
nota_aluno_aprovado = list(map(obter_nota, alunos_aprovados)) #obtem a nota dos alunos aprovados
total = reduce(somar, nota_aluno_aprovado, 0) #soma a nota dos alunos aprovados
print(nota_aluno_aprovado) 
print(total / len(nota_aluno_aprovado))