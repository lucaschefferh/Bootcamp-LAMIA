from functools import reduce

alunos = [
    {"nome":"Pedro", "nota": 7.0},
    {"nome":"Francisco", "nota": 4.0},
    {"nome":"João", "nota": 3.0},
    {"nome":"Lucas", "nota": 9.0},
    {"nome":"Caio", "nota": 6.0},
]

somar = lambda a, b: a + b #funcao lambda para somar elementos 

alunos_aprovados = [aluno for aluno in alunos if aluno['nota'] >= 7]  #filtra os alunos aprovados
nota_aluno_aprovado = [aluno['nota'] for aluno in alunos_aprovados] #obtem a nota dos alunos aprovados
total = reduce(somar, nota_aluno_aprovado, 0) #soma a nota dos alunos aprovados
print(nota_aluno_aprovado) 
print(total / len(nota_aluno_aprovado)) 

#foi o mesmo funcionamento da função lambda porém com outra maneira de escrita
