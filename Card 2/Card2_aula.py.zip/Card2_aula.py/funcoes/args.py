def soma(*nums): #tupla passada como argumento
    total = 0 
    for n in nums: #loop percorrendo toda a tupla
        total += n #soma
    return total

def resultado_final(**kwargs): #dicionario passado como parametro
    status = "aprovado" if kwargs["nota"] >=7 else "Reprovado" #operador ternario para verificar se foi aprovado
    return f'{kwargs["nome"]} foi {status}' #retorno da funcao

def resultado_final(**kwargs): #dicionario passado como parametro
    nota = kwargs.get("nota", 0) #nota padrao é 0
    comportado = kwargs.get("comportado", True) #comportamento padrao é True
    nome = kwargs.get("nome", "Aluno") #nome padrao é Aluno
     
    status = "Aprovado" if nota >= 7 else "Reprovado" #verificacao de nota 
    
    if not comportado: # verificao de comportamento
        status = "Reprovado por comportamento" 
    
    return f'{nome} foi {status}, com média {nota}' #retorno da funcao
    