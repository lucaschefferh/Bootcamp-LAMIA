def saudacao(nome = "Pessoa", idade = 20): #paremetro padrao caso fique vazio
    print(f"Bom dia {nome}, você tem {idade} anos")

if __name__ == "__main__": #funciona quando é executado no main
    saudacao(nome = "Ana", idade = 20)

#def saudacao():  #sobreescrita
#    print("Bom dia")

def soma_e_multi(a,b,x): #com x*b acontecendo primeiro e dps a soma desse resultado com a
    return a+b*x


