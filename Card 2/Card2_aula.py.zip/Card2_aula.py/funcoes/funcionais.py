def soma(a,b):
    return a+b #retorna a soma dos dois parametros

def sub(a,b):
    return a-b #retorna a diferença entre os dois parametros

somar = soma(12, 45)
print(somar)

def operacao_aritmetica(fn,op1,op2): #passado como parametro, uma funcao e dois operadores
    return fn(op1,op2) #retorna a funcao operando com os dois operadores

resultado = operacao_aritmetica(soma, 15, 34)
print(resultado)

resultado = operacao_aritmetica(sub, 15, 34)
print(resultado)


def soma_parcial(a):  #define uma funçao que recebe um argumento 
    def concluir_soma(b):  #define uma funçao que recebe um argumento
        return a + b  #oma os dois argumentos passados
    return concluir_soma  #retorno da funcao


soma_1 = soma_parcial(1) #primeiro parametro passado como 1
r1 = soma_1(2) # 1 + 2
r2 = soma_1(3) # 1 + 3
r3 = soma_1(4) # 1 + 4

resultado_final = soma_parcial(10)(12) 
print(resultado_final,r1,r2,r3 )

