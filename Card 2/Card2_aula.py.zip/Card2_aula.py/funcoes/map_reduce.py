from functools import reduce

def soma_nota(delta):
    def calc(nota):
        return nota + delta
    return calc

notas = [6.4, 7.2, 5.4, 8.4]


notas_finais_1 = list(map(soma_nota(1.5), notas))  #soma 1.5 a cada nota
notas_finais_2 = list(map(soma_nota(1.6), notas))  #soma 1.6 a cada nota

notas_finais = list(notas_finais_1)
notas_finais = list(notas_finais_2)

total=0

# Soma total das notas usando for
for n in notas:
    total+=n

print(total) 

def soma(a,b):
    return a+b

# Soma total das notas usando reduce
total = reduce(soma,notas,0) 

print(total)

print(notas_finais)

#for i, nota in enumerate(notas):
    #notas[i] = nota+1.5


#for i in range(len(notas)):
#    notas[i] = notas[i]+1.5
    