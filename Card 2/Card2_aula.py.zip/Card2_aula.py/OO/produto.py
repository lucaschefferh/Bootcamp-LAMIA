class produto:
   def __init__(self,nome, preco = 3.50, desc=0):
        self.nome = nome
        self.__preco = preco
        self.desc = desc

   @property #getter utilizado para quando o atributo esta privado
   def preco(self):
        return self.__preco
    
   @preco.setter #setter 
   def preco(self, novo_preco):
     if novo_preco > 0:
        self.__preco = novo_preco

   @property #calcular o preço final considerando o desconto
   def preco_final(self):
     return (1-self.desc) * self.preco    

    #printa a tabela inteira
   def exibir_info(self):
    print(f"Produto: {self.nome}")
    print(f"Preço Original: R${self.preco}")
    print(f"Desconto: {self.desc*100}%")
    print(f"Preço Final: R${self.preco_final:.2f}")


p1 = produto("Caneta", 5.99, 0.10)
p2 = produto("Caderno", 12.99, 0.10)

p1.exibir_info()
print("")
p2.exibir_info()
print("")
p1.preco = -70
p2.preco = - 2

print(f'Produto:{p1.nome}: \nPreço:{p1.preco} \nDesconto:{p1.desc}. \nPreço final:{p1.preco_final}')
print("")
print(f'Produto:{p2.nome}: \nPreço:{p2.preco} \nDesconto:{p2.desc}. \nPreço final:{p2.preco_final}')