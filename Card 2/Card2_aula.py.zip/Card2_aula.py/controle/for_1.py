#loop de 0 a 9, verificando qual é par, qual é impar
for x in range(10):
    if x % 2 == 0:
        print(f"{x} é par", end=" ")
    else:
        print(f"{x} é ímpar", end=" ")


#soma dos numeros de 1 a 10
soma = 0
for y in range(1, 10):
    soma += y
print(f"\nSoma total: {soma}")

#print de 0 a 100, pulando de 10 em 10
for i in range(0,101, 10):
    print(i,end = " ")

print(f'\n')#deixar o console mais organizado

#print de 30 até 0 de 3 em 3
for i in range(30, 0, -3):
    print(i,end = " ")

print(f'\n')#deixar o console mais organizado

nums = [2,4,6,8]
for n in nums:
    print(n, end = " ") #print de cada elemento da lista
print(f'\n')

texto = "Python"

for letra in texto:
    print(letra, end = " ") #print de cada elemento de uma String

print(f'\n')
for n in {1,2,3,4,4,4}:
    print(n, end = " ") #print de cada elemento de um conjunto
print(f'\n')

#dicionario para exemplo
produto = {
    "nome": "Arroz",
    "valor": 5.0,
    "quantidade": 15
}

for atrib in produto:
    print(atrib,"-->", produto[atrib]) #print da chave e do valor seguidos
print(f'\n')

for atrib,valor in produto.items():
    print(atrib,"-->", valor) #outra maneira de printar  
print(f'\n')

for valor in produto.values(): 
    print(valor,end = " ") #print apenas dos valores
print(f'\n')

for atrib in produto.keys():
    print(atrib,end = " ") #print apenas das chaves