a = "valor"
a = 0 #false
a = -0.001
a = "" #false
a = " "
a = [] #false
a = {} #false

if a:
    print("Existe! ")

else:
    print("Nao existe ou zero ou vazio... ")