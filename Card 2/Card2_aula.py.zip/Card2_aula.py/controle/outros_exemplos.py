pessoas = ["Lucas", "João"]
adj = ["Irritado", "Inteligente"]
 
for p in pessoas: #for para percorrer todas as pessoas
    for a in adj: #for dentro do for para percorrer todos os adjetivos
        print(f"{p} é {a}!") 

print("")

for i in [1,2,3]:
    pass

print("")

for i in range(1,11): #for comecando em 1 e indo ate 10
    if i % 2 == 1: #verificacao de impar 
        continue
    print(i, end = " ") #print dos pares

print("")

#Decrescente de 10 a 1 mostrando qual e divisivel por 3
for i in range(10, 0, -1):  
    if i % 3 == 0:
        print(f"{i} é divisível por 3")
    else:
        print(f'{i} não é divisivel por 3')

print("")

for i in range(1,11): #for comecando em 1 e indo ate 10
    if i == 5: #quando i for igual a 5 o if acaba
        break
    print(i, end = " ")
    
print("Fim")