x=10
while x:
    print(x) #vai printar o x de 10 até 1
    x-=1

#verificar se e par ou impar com while
y = 15
while y > 0: #loop
    if y % 2 == 0: #verificacao
        print(f"{y} é par!")
    else:
        print(f"{y} é ímpar!")
    y -= 1 #decremento

print("Fim")

total = 0
qtde = 0
nota = 0

while nota != -1: #loop caso nota seja diferente de -1
    nota = float(input("Informe a nota ou -1 para sair: ")) #input para entrada de dados
    if nota!=-1: #se o dado digitado for diferente de -1 ele entra na verificacao
        qtde += 1 #aumenta a quantidade
        total +=nota #acrescenta ao total a nota digitada
 

print(f"A media da turma é: {total/qtde}") 