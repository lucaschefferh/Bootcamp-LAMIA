idade = 18
categoria = "adulto" if idade >= 18 else "menor" 
print(categoria)
print(f"Com {idade} você é {categoria}")