x = 7
y = 5


#sempre retorna valor booleano
print(x>y) #7 é maior que 5?
print(x>=y) #7 é maior ou igual que 5?
print(x<=y) #7 é menor ou igual que 5?
print(x<y)  #7 é menor que 5?
print(x==y) #7 é igual que  5?
print(x!=y) #7 é diferente de 5?

print('5'!= 5) #True pois está em tipos de variavel diferente