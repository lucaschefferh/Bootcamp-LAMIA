x = 10
y = 3.0

print(x+y) #soma
print(x-y) #subtração
print(x*y) #multiplicação
print(x/y) #divisão
print(x%y) #resto

par = 12
impar = 15

print(par%2==0) #resto da divisao de 12 por 2 é 0, logo verdade
print(impar%2==1) #resto da divisao de 15 por 2 é 1, logo verdade