resultado = 2 #atribuindo valor a variavel
resultado += resultado #somando o valor de resultado a resultado
resultado += 3 #somando o valor de resultado + 3
resultado -=4 #diminuindo o valor de resultado -4
resultado *=4 #multiplicando o valor de resultado por 7
resultado /=4 #dividindo o valor de resultado por 4
resultado %=5 #vendo o resto do valor de resultado por 5


print(resultado)

resultado = "String"
print(resultado)