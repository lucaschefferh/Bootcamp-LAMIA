b1 = True
b2 = False
b3 = True

print(b1 and b2 and b3) #True se todos forem True
print(b1 or b2 or b3) #True se apenas um for True
print(b1 and b3) #True se todos forem True
print(b1 != b2) #True se forem diferentes 
print(not b1) #Inverte o valor
print(not b2)  #Inverte o valor

print(b1 and not b2 and b3) #True se todos forem True

x = 3
y = 4

print(b1 and not b2 and x < y) #True se todos forem True