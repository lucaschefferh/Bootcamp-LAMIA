y=4
print(not False) # operador not
print(not True) 
print(--6) #operador '-' 
print(-y)   
print(+8)

w=13 
#w++ # nao existe incrementação assim 
print(w)