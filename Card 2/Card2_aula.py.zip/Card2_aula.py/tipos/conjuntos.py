
print(type({1,2,3})) # declaracão com chaves que nem o dicionario

conj = {1,2,3,4,5,5,5,5} # nao permite repeticao
#print(conj[]) conjunto não tem indice

print(len(conj)) # ignora a repetição do elemento 5


