nums = [1, 4, 5 ,6, 9]
print(type(nums))
nums.append(4)  #adiciona a lista o elemento 2
nums.append(9)  #adiciona a lista o elemento 2
nums.append(2)  #adiciona a lista o elemento 2

print(len(nums)) #conta quantos elementos tem na lista 

nums[4] = 540 # altera o elemento de indice 4 para 540
print(nums)

nums.insert(0 , 400) #insere na lista 
print(nums)

print(nums[-1]) #acessa o ultimo elemento