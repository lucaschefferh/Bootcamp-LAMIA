#declaracao dicionario
aluno = {
    'nome': "Lucas Scheffer",
    'nota' : 8.6, 
    'serie' : "primeiro ano"
}

print(type[aluno]) 
print(type[aluno['nota']])

print(aluno["nome"])
print(aluno["nota"])
print(aluno["serie"])

print(len(aluno))