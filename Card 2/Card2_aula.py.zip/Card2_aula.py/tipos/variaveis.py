a = 7
b = 5
print(a + b)

texto = 'Sua idade é... '

print(texto + str(a+b)) #necessario usar o cast para trasnformar int em str
print(f'{texto}{a + b}') # necessario usar o f'' para poder formatar a print e concatenar str e int 

saudacao = 'tudo bem? '

print(3 * saudacao ) #possivel fazer multiplicaco de str para aparecer quantas vezes quiser

PI = 3.14
raio = float(input("Informe o numero do raio "))

print(type(raio)) # por padrao vem como str mas usando o cast conseguimos trocar para float ou int 

area = PI * pow(raio, 2) # pow é uma função que eleva algo ao segundo elemento que voce colocar
#area = PI * raio * raio

print(f"O tamanho da área é {area}")