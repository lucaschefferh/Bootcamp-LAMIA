nome = ('Ana', 'Bia', 'Lucas', 'André')

print('Lucas' in nome) # retorna valor booleano dizendo se é falso ou verdadeiro

print(nome[0]) #primeiro elemento, que fica no indice 0
print(nome[1:3]) #do segundo elemento e para no 3
print(nome[1:-1]) # do segundo ao penultimo    
print(nome[2:]) #do terceiro até o final
print(nome[:-2]) #do começo até 2 elementos antes do final  
print(len(nome)) #quantidade de elementos
print(type(nome)) 
print(nome)