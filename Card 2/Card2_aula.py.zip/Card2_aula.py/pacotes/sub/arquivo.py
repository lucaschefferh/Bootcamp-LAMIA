print("Funcionou")
print(__name__)
print(__package__)
print(abs(-450))